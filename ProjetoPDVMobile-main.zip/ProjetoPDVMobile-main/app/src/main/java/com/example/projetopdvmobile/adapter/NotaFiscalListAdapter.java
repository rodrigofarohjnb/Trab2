package com.example.projetopdvmobile.adapter;

public class NotaFiscalListAdapter {
}
