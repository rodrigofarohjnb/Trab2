package com.example.projetopdvmobile.dao;

public class AdmDAO {
}
