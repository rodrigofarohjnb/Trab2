package com.example.projetopdvmobile.controller;

public class AdmController {
}
